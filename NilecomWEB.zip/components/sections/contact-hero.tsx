const ContactHero = () => {
  return (
    <section >
    
    </section>
  )
}

export default ContactHero
